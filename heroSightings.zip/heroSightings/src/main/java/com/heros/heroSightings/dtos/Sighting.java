/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.heros.heroSightings.dtos;

import static java.util.Calendar.DATE;

/**
 *
 * @author triplexlj
 */
public class Sighting {
   
    private String SightingsID;//properties or data members
    
    private String LocationID;
    
    private String CharacterID;
    
    private String timeStamp;
    
    
}
